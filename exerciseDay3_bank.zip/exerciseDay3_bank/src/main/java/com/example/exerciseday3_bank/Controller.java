package com.example.exerciseday3_bank;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/v1")
public class Controller {

    ArrayList<Customer> customers = new ArrayList<>();

   @GetMapping("/customer")
    public ArrayList<Customer> getCustomers(){
        return customers;
    }

    @PostMapping("/add")
    public ApiResponse addCustomer(@RequestBody Customer customer){
        customers.add(customer);
        return new ApiResponse("customer added!");
    }

    @PutMapping("/update/{index}")
    public ApiResponse updateCustomer (@PathVariable int index , @RequestBody Customer customer){
        customers.set(index, customer);
        return new ApiResponse("customer updated!");
    }

    @DeleteMapping ("/delete/{index}")
    public ApiResponse deleteCustomer (@PathVariable int index){
        customers.remove(index);
        return new ApiResponse("customer deleted!");
    }

    @PutMapping("/deposit/{amount}/{ID}")
    public ApiResponse depositAmount(@PathVariable int amount , @PathVariable int id){
        customers.get(id).setBalance( customers.get(id).getBalance() + amount);
        return new ApiResponse("Deposited");
    }




}

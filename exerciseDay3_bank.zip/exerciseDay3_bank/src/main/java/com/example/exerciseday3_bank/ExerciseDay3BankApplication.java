package com.example.exerciseday3_bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExerciseDay3BankApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExerciseDay3BankApplication.class, args);
    }

}

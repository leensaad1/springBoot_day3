package com.example.exerciseday3_bank;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Customer {

    private String id;
    private String userName;
    private String balance;


}

package com.example.exerciseday3_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExerciseDay31ApplicationTests {

    @Test
    void contextLoads() {
    }

}

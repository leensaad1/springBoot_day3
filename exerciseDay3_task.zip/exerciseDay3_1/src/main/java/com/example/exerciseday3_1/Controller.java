package com.example.exerciseday3_1;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/v1")
public class Controller {

    ArrayList<Task> tasks = new ArrayList<>();

    @GetMapping("/task")
    public ArrayList<Task> getTasks() {
        return tasks;
    }

    @PostMapping("/add")
    public ApiResponse addTask (Task task){
        tasks.add(task);
        return new ApiResponse("task added!");
    }

    @PutMapping ("/update/{index}")
        public ApiResponse updateTask (@PathVariable int index , @RequestBody Task task){
        tasks.set(index, task);
        return new ApiResponse("task updated!");
    }

    @DeleteMapping ("/delete/{index}")
    public ApiResponse deleteTask (@PathVariable int index){
        tasks.remove(index);
        return new ApiResponse("task deleted!");
    }


    @GetMapping("/search")
    public Task searchTask (@RequestBody Task task){
        return task;
    }

    @PutMapping("/status/{index}")
    public ApiResponse changeStatus(@PathVariable int index, @RequestBody Task  task) {
        tasks.get(index).setStatus(task.getStatus());
        return new ApiResponse("status updated!");
    }


}
